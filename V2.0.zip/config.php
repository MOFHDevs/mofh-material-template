<?php
$mofh = array(
     
'title' => 'Endless Free', // Site title
     
'description' => 'Get Free Professional Web Hosting for your Website', // Site Description
    
'logo' => 'http://domain.tld/img/logo.png', // Logo URL
     
'protocol' => 'http://', // it is https or http
   
 'favicon' => '/img/favicon.ico', // your website favicon url
     
 'affid' => '26422', // your ifastnet affiliate id

 'mail' => 'shaleshgujjar2001@gmail.com', // email here
     
 'facebook' => 'https://www.facebook.com/#', // your facebook link
     
 'twitter' => 'https://twitter.com/#', // your twitter link
     
 'google-plus' => 'https://plus.google.com/#', // your google plus link
     
 'linkedin' => 'https://www.linkedin.com/in/#', // your linkedin link

'domain' => strtolower(preg_replace('/^www\./' , '' , $_SERVER['HTTP_HOST'])), // Automatic Domain Recognition

);
?>
