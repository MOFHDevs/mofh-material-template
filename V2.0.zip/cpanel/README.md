# cPanel Login for MOFH  
cPanel Login for MOFH is a login/signup template using cPanel design to bring the cPanel experience to your reseller.  

## How to install it?  
You just need to download it from [here](https://github.com/VizuDev/cPanel-Login-for-MOFH/archive/master.zip) and extract it's contents.  
Then, copy and paste them on your site and the template should be installed!  

Don't forget to replace any links with the new login and signup links.  

## Copyright Info

Copyright (C) 2018 VizuDev. All Rights Reserved.

[![Licensed under the CC-BY-4.0](https://img.shields.io/github/license/VizuDev/cPanel-Login-for-MOFH.svg?style=for-the-badge)](https://github.com/VizuDev/cPanel-Login-for-MOFH/blob/master/LICENSE.md)


If you see any errors, please create a PR.
For any additional support, please join our [Discord Server](https://invite.gg/vizudev).
